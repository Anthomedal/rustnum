/*
Copyright 2020 Anthony Gerber-Roth
This file is part of rustnum.

rustnum is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

rustnum is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with rustnum.  If not, see <https://www.gnu.org/licenses/>.
*/

// !!! A TESTER !!!

// Standard matrices 
#[derive(Clone)]
pub struct Dense
{
    // Size's Matrix
    pub n: usize,
    pub m: usize,

    // Values
    pub v: Vec<f64>
}

impl Dense
{
    pub fn zeros(n_init: usize, m_init: usize) -> Dense
    {
        let to_return = Dense {
            n: n_init,
            m: m_init,
            v: vec![0f64;n_init*m_init]
        };

        return to_return;
    }

    pub fn print(&self)
    {
        let mut self_ij: usize;

        for i in 0..self.n
        {
            print!("[");

            for j in 0..self.m
            {
                self_ij = i + j*self.n;

                print!(" {} ", self.v[i + j*self.n]);
            }

            println!("]");
        }
    }

    pub fn set(&mut self, i: usize, j: usize, x: f64)
    {
        if i < self.n && j < self.m
        {
            self.v[i + j*self.n] = x;
        }
        else
        {
            panic!("rustnum error : attempt to access to out of bound element in Dense matrix.");
        }
    }

    pub fn get(& self, i: usize, j: usize) -> f64
    {
        if i < self.n && j < self.m
        {
            return self.v[i + j*self.n];
        }
        else
        {
            panic!("rustnum error : attempt to access to out of bound element in Dense matrix.");
        }
    }
/*
    pub fn block_decomposition(&self, given_from_rows: usize, given_to_rows: usize,
                               given_from_columns: usize, given_to_columns: usize) -> Dense
    {
        /*
        Extract the block between given indexes
        */

        let to_return = Dense {
            n: given_to_rows - given_from_rows,
            m: given_to_columns - given_from_columns,
            sub_matrix: true,
            values_n: self.n,
            from_rows: given_from_rows + self.from_rows,
            from_columns: given_from_columns + self.from_columns,
            to_rows: given_to_rows,
            to_columns: given_to_columns,
            v: Rc::clone(&self.v)
        };

        return to_return;
    }

    pub fn is_sub_matrix(&self) -> bool 
	{
		return self.sub_matrix;
	}
*/
}
