/*
Copyright 2020 Anthony Gerber-Roth
This file is part of rustnum.

rustnum is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

rustnum is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with rustnum.  If not, see <https://www.gnu.org/licenses/>.
*/

// !!! A TESTER !!!

// Diagonals matrices
pub struct Diagonal
{
    // Size's Matrix
    pub n: usize,

    // Values
    pub v: Vec<f64>
}

impl Diagonal
{
    pub fn zeros(n_init: usize) -> Diagonal
    {
        let to_return = Diagonal {
            n: n_init,
	        // We only need to save diagonal values 
            v: vec![0f64;n_init]
        };

        return to_return;
    }

    pub fn eye(n_init: usize) -> Diagonal
    {
	    // Construct I_n identity matrix 
	    let to_return = Diagonal {
            n: n_init,
            v: vec![1f64;n_init]
        };

        return to_return;
    }
    
    pub fn print(&self)
    {
        for i in 0..self.n
        {
            print!("[");

            for j in 0..self.n
            {

                if i == j
                {
                    print!(" {} ", self.v[i]);
                }
                else
                {
                    print!(" {} ", 0f64);
                }
            }

            println!("]")
        }
    }

    pub fn set(&mut self, i: usize, x: f64)
    {
        if i < self.n
        {
            self.v[i] = x;
        }
    }

    /*
    pub fn block_decomposition(&self, given_from: usize, given_to: usize) -> Diagonal
    {
        /*
        Extract the block between given indexes
        */

        let to_return = Diagonal {
            n: given_to - given_from,
            sub_matrix: true,
            values_n: self.n,
            from: given_from + self.from,
            to: given_to,
            v: Rc::clone(&self.v)
        };

        return to_return;
    }

    pub fn is_sub_matrix(&self) -> bool 
	{
		return self.sub_matrix;
    }
    */

}
