/*
Copyright 2020 Anthony Gerber-Roth
This file is part of rustnum.

rustnum is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

rustnum is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with rustnum.  If not, see <https://www.gnu.org/licenses/>.
*/

// !!! A TESTER !!!

// Lower Triangular matrices 
#[derive(Clone, Debug)]
pub struct LowerTriangular
{
    // Size's Matrix
    pub n: usize,

    // Values
    pub v: Vec<f64>
}

impl LowerTriangular
{
    pub fn zeros(n_init: usize) -> LowerTriangular
    {
        let to_return = LowerTriangular {
            n: n_init,
            // We only save under diagonal elements
            v: vec![0f64;((n_init)*(n_init+1))/2]
        };

        return to_return;
    }

    pub fn eye(n_init: usize) -> LowerTriangular
    {
        let mut to_return = LowerTriangular {
            n: n_init,
            // We only save under diagonal elements
            v: vec![0f64;((n_init)*(n_init+1))/2]
        };

        for i in 0..n_init 
        {
            to_return.v[((((i as isize)*((i as isize)-1))/2) as usize) + 2*i] = 1f64;
        }

        return to_return;
    }

    pub fn print(&self)
    {
        let mut self_ij: usize;
	
        for i in 0..self.n
	    {
            print!("[");
            
            for j in 0..(i+1)
            {
                // This is the formula which allow us to access to elements
                self_ij = ((((i as isize)*((i as isize)-1))/2) as usize) + i+j;

                print!(" {} ", self.v[self_ij]);
            }

            for _ in (i+1)..self.n
            {
                print!(" {} ", 0f64);
            }

            println!("]");
	    }
    }

    pub fn set(&mut self, i: usize, j: usize, x: f64)
    {
        if i < self.n && j <= i
        {
            let self_ij = ((((i as isize)*((i as isize)-1))/2) as usize) + i+j;

            self.v[self_ij] = x;
        }
        else
        {
            panic!("rustnum error : attempt to access to non upper element in upper triangular matrix.");
        }
    }

    pub fn get(&self, i: usize, j: usize) -> f64 
    {
        if i < self.n && j <= i
        {
            let self_ij = ((((i as isize)*((i as isize)-1))/2) as usize) + i+j;

            return self.v[self_ij];
        }
        else
        {
            panic!("rustnum error : attempt to access to non upper element in upper triangular matrix.");
        }
    }

    /*
    pub fn block_decomposition(&self, given_from: usize, given_to: usize) -> LowerTriangular
    {
        /*
        Extract the block between given indexes
         */

        let to_return = LowerTriangular {
            n: given_to - given_from,
            sub_matrix: true,
            from: given_from + self.from,
            v: Rc::clone(&self.v)
        };

        return to_return;
    }

    pub fn is_sub_matrix(&self) -> bool 
	{
		return self.sub_matrix;
    }
    */

}
