/*
Copyright 2020 Anthony Gerber-Roth
This file is part of rustnum.

rustnum is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

rustnum is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with rustnum.  If not, see <https://www.gnu.org/licenses/>.
*/

use crate::linear_algebra::dense::Dense; 

pub fn dense(v: &Dense) -> f64
{
    // Compute euclidian norm of v 

    let mut sum: f64 = 0.0;

    if v.n == 1 
    {
        let m = v.m;
        let mut v_i: f64;

        for i in 0..m
        {
            v_i = v.get(0,i);

            sum = sum + v_i*v_i;
        }

        return sum.sqrt();
    }
    else if v.m == 1
    {
        let n = v.n;
        let mut v_i: f64;

        for i in 0..n
        {
            v_i = v.get(i,0);

            sum = sum + v_i*v_i;
        }

        return sum.sqrt();
    }
    else 
    {
        panic!("Matrix norm no build yet.");
    }
}