/*
Copyright 2020 Anthony Gerber-Roth
This file is part of rustnum.

rustnum is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

rustnum is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with rustnum.  If not, see <https://www.gnu.org/licenses/>.
*/

use crate::linear_algebra::dense::Dense;
use crate::linear_algebra::diagonal::Diagonal;
use crate::linear_algebra::lower_triangular::LowerTriangular;
use crate::linear_algebra::symmetric::Symmetric;
use crate::linear_algebra::tridiagonal::Tridiagonal;
use crate::linear_algebra::upper_triangular::UpperTriangular;

pub fn dense(x: f64, a: &Dense, p: &mut Dense)
{
    if a.n == p.n && a.m == p.m 
    {
        for i in 0..(a.n*a.m)
        {
            p.v[i] = x*a.v[i];
        }
    }
    else
    {
        panic!("Inconsistent matrix size in scalar multiplication.");
    }
}

pub fn diagonal(x: f64, a: &Diagonal, p: &mut Diagonal)
{
    if a.n == p.n
    {
        for i in 0..a.n
        {
            p.v[i] = x*a.v[i];
        }
    }
    else
    {
        panic!("Inconsistent matrix size in scalar multiplication.");
    }
}

pub fn lower_triangular(x: f64, a: &LowerTriangular, p: &mut LowerTriangular)
{
    if a.n == p.n
    {
        for i in 0..(((a.n)*(a.n+1))/2)
        {
            p.v[i] = x*a.v[i];
        }
    }
    else
    {
        panic!("Inconsistent matrix size in scalar multiplication.");
    }
}

pub fn symmetric(x: f64, a: &Symmetric, p: &mut Symmetric)
{
    if a.n == p.n
    {
        for i in 0..(((a.n)*(a.n+1))/2)
        {
            p.v[i] = x*a.v[i];
        }
    }
    else
    {
        panic!("Inconsistent matrix size in scalar multiplication.");
    }
}

pub fn tridiagonal(x: f64, a: &Tridiagonal, p: &mut Tridiagonal)
{
    if a.n == p.n
    {
        for i in 0..(((a.n)*(a.n+1))/2)
        {
            p.v[i] = x*a.v[i];
        }
    }
    else
    {
        panic!("Inconsistent matrix size in scalar multiplication.");
    }
}

pub fn upper_triangular(x: f64, a: &UpperTriangular, p: &mut UpperTriangular)
{
    if a.n == p.n
    {
        for i in 0..(3*(a.n-2)+4)
        {
            p.v[i] = x*a.v[i];
        }
    }
    else
    {
        panic!("Inconsistent matrix size in scalar multiplication.");
    }
}