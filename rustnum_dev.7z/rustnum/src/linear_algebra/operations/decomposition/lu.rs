/*
Copyright 2020 Anthony Gerber-Roth
This file is part of rustnum.

rustnum is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

rustnum is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with rustnum.  If not, see <https://www.gnu.org/licenses/>.
*/

use crate::linear_algebra::dense::Dense; 
use crate::linear_algebra::lower_triangular::LowerTriangular;
use crate::linear_algebra::upper_triangular::UpperTriangular;
use rayon::prelude::*;
use std::sync::{Mutex, Arc, RwLock};
use std::borrow::Borrow;

pub fn dense(a: &Dense) -> (LowerTriangular, UpperTriangular)
{
    /*
    Implement LU decomposition for dense matrices
    This function use Doolitle Algorithm 
    */ 

    if a.n == a.m 
    {
        let n = a.n;

        let mut l = LowerTriangular::eye(n);
        let mut u = UpperTriangular::zeros(n); 

        let mut sum = 0f64;

        for i in 0..(n-1)
        {
            for j in i..n 
            {
                // Sum calculus 
                sum = 0f64;

                for k in 0..i
                {
                    sum = sum + l.get(i,k)*u.get(k,j);
                }


                u.set(i,j, a.get(i,j) - sum);
            }

            for j in (i+1)..n 
            {
                // Sul calculus
                sum = 0f64;

                for k in 0..i
                {
                    sum = sum + l.get(j,k)*u.get(k,i);
                }

                l.set(j,i, (1f64/u.get(i,i)*(a.get(j,i)-sum)));
            }
        }

        // Sum calculus 
        sum = 0f64; 

        for k in 0..n
        {
            sum = sum + l.get(n-1,k)*u.get(k,n-1);
        }

        u.set(n-1, n-1, a.get(n-1,n-1) - sum);

        return (l,u);
    }
    else
    {
        panic!("Impossible LU factorization");
    }
}

pub fn par_dense(a: &Dense) -> (LowerTriangular, UpperTriangular)
{
    /*
    Implement LU decomposition for dense matrices
    This function use Doolitle Algorithm 
    */ 

    if a.n == a.m 
    {
        let n = a.n;

        let mut l = Arc::new(Mutex::new(LowerTriangular::eye(n)));
        let mut u = Arc::new(Mutex::new(UpperTriangular::zeros(n))); 

        // Variables for parallel operations 
        let mut iterator: Vec<usize>;

        for i in 0..(n-1)
        {
            iterator = (i..n).collect();

            iterator.par_iter().for_each(|j|
            {
                // Sum calculus 
                let mut sum = 0f64;

                for k in 0..i
                {
                    sum = sum + (*(l.lock().unwrap())).get(i,k)*(*(u.lock().unwrap())).get(k,*j);
                }


                u.lock().unwrap().set(i,*j, a.get(i,*j) - sum);
            });

            iterator = ((i+1)..n).collect();

            iterator.par_iter().for_each(|j|
            {
                // Sul calculus
                let mut sum = 0f64;

                for k in 0..i
                {
                    sum = sum + (*(l.lock().unwrap())).get(*j,k)*(*(u.lock().unwrap())).get(k,i);
                }

                l.lock().unwrap().set(*j,i, (1f64/(*(u.lock().unwrap())).get(i,i)*(a.get(*j,i)-sum)));
            });
        }

        // Sum calculus 
        let mut sum = 0f64; 

        for k in 0..n
        {
            sum = sum + (*(l.lock().unwrap())).get(n-1,k)*(*(u.lock().unwrap())).get(k,n-1);
        }

        u.lock().unwrap().set(n-1, n-1, a.get(n-1,n-1) - sum);

        return (Arc::try_unwrap(l).unwrap().into_inner().unwrap(),Arc::try_unwrap(u).unwrap().into_inner().unwrap());
    }
    else
    {
        panic!("Impossible LU factorization");
    }
}

pub fn par_dense2(a: &Dense) -> (LowerTriangular, UpperTriangular)
{
    /*
    Implement LU decomposition for dense matrices
    This function use Doolitle Algorithm 
    */ 

    if a.n == a.m 
    {
        let n = a.n;

        let mut l = Arc::new(RwLock::new(LowerTriangular::eye(n)));
        let mut u = Arc::new(RwLock::new(UpperTriangular::zeros(n))); 

        // Variables for parallel operations 
        let mut iterator: Vec<usize>;

        for i in 0..(n-1)
        {
            iterator = (i..n).collect();

            iterator.par_iter().for_each(|j|
            {
                // Sum calculus 
                let mut sum = 0f64;

                for k in 0..i
                {
                    sum = sum + (l.read().unwrap()).get(i,k)*(u.read().unwrap()).get(k,*j);
                }


                u.write().unwrap().set(i,*j, a.get(i,*j) - sum);
            });

            iterator = ((i+1)..n).collect();

            iterator.par_iter().for_each(|j|
            {
                // Sul calculus
                let mut sum = 0f64;

                for k in 0..i
                {
                    sum = sum + (l.read().unwrap()).get(*j,k)*(u.read().unwrap()).get(k,i);
                }

                l.write().unwrap().set(*j,i, (1f64/(u.read().unwrap()).get(i,i)*(a.get(*j,i)-sum)));
            });
        }

        // Sum calculus 
        let mut sum = 0f64; 

        for k in 0..n
        {
            sum = sum + (l.read().unwrap()).get(n-1,k)*(u.read().unwrap()).get(k,n-1);
        }

        u.write().unwrap().set(n-1, n-1, a.get(n-1,n-1) - sum);

        return (Arc::try_unwrap(l).unwrap().into_inner().unwrap(),Arc::try_unwrap(u).unwrap().into_inner().unwrap());
    }
    else
    {
        panic!("Impossible LU factorization");
    }
}