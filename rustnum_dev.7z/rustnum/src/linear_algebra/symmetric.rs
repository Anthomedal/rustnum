/*
Copyright 2020 Anthony Gerber-Roth
This file is part of rustnum.

rustnum is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

rustnum is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with rustnum.  If not, see <https://www.gnu.org/licenses/>.
*/

// !!! A TESTER !!!

// Symmetric matrices 
#[derive(Clone)]
pub struct Symmetric
{
    // Size's Matrix
    pub n: usize,

    // Values
    pub v: Vec<f64>
}

impl Symmetric
{
    pub fn zeros(n_init: usize) -> Symmetric
    {
        let to_return = Symmetric {
            n: n_init,
            // We only save under diagonal elements
            v: vec![0f64;((n_init)*(n_init+1))/2]
        };

        return to_return;
    }

    pub fn print(&self)
    {
        let mut self_ij: usize;
	
        for i in 0..self.n
	    {
            print!("[");

            for j in 0..i
            {
                // We first print element on the left of diagonal
                self_ij = ((((i as isize)*((i as isize)-1))/2) as usize) + i+j;
                print!(" {} ", self.v[self_ij]);
            }
            
            for j in i..self.n
            {
                // Now we print element on the right of the diagonal 
                // To do that we need to print elements of i-th column (by symmetry)
                self_ij = ((((j as isize)*((j as isize)-1))/2) as usize) + i+j;
                print!(" {} ", self.v[self_ij]);
            }

            println!("]");
	    }  
    }

    pub fn set(&mut self, i: usize, j: usize, x: f64)
    {
        if j < self.n && i <= j
        {
            let self_ij = ((((j as isize)*((j as isize)-1))/2) as usize) + i+j;

            self.v[self_ij] = x;
        }
        else if i < self.n && j <= i
        {
            let self_ij = ((((i as isize)*((i as isize)-1))/2) as usize) + i+j;

            self.v[self_ij] = x;
        }
        else
        {
            panic!("rustnum error : attempt to access to non upper element in upper triangular matrix.");
        }
    }

    /*
    pub fn block_decomposition(&self, given_from: usize, given_to: usize) -> Symmetric
    {
        /*
        Extract the block between given indexes
         */

        let to_return = Symmetric {
            n: given_to - given_from,
            sub_matrix: true,
            from: given_from + self.from,
            v: Rc::clone(&self.v)
        };

        return to_return;
    }

    pub fn is_sub_matrix(&self) -> bool 
	{
		return self.sub_matrix;
	}
    */
}
