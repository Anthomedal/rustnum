use rustnum::linear_algebra::dense::Dense;
use rustnum::linear_algebra::diagonal::Diagonal;
use rustnum::linear_algebra::operations::basics::*;
use rustnum::linear_algebra::tridiagonal::Tridiagonal;
use rustnum::linear_algebra::upper_triangular::UpperTriangular;
use rustnum::linear_algebra::symmetric::Symmetric;
use rustnum::linear_algebra::lower_triangular::LowerTriangular;
use rustnum::linear_algebra::operations::*;
use std::sync::{Mutex, Arc};

fn main() {
    test_product_dense_dense();
}

fn test_par_factorisation_lu2()
{
    const S:usize = 1000;

    let mut a = Dense::zeros(S,S);

    for i in 0..S 
    {
        a.set(i,i,2f64);
    }
    let (l,u) = decomposition::lu::par_dense2(&a);

    l.print();
    u.print();

    // Vérifier si on retrouve A
    a.print();

    let mut anew = Dense::zeros(S,S);

    product::lower_triangular_upper_triangular(&l, &u, &mut anew);

    anew.print();
}

fn test_probleme() -> f64 
{
    let mut a = Arc::new(Mutex::new(5f64));

    return Arc::try_unwrap(a).unwrap().into_inner().unwrap();
}

fn test_par_factorisation_lu()
{
    const S:usize = 1000;

    let mut a = Dense::zeros(S,S);

    for i in 0..S 
    {
        a.set(i,i,2f64);
    }
    let (l,u) = decomposition::lu::par_dense(&a);

    l.print();
    u.print();

    // Vérifier si on retrouve A
    a.print();

    let mut anew = Dense::zeros(S,S);

    product::lower_triangular_upper_triangular(&l, &u, &mut anew);

    anew.print();
}

fn test_factorisation_lu()
{
    const S:usize = 3;

    let mut a = Dense::zeros(S,S);

    a.v = vec![1f64,2f64,3f64,4f64,5f64,6f64,7f64,8f64,9f64];

    let (l,u) = decomposition::lu::dense(&a);

    l.print();
    u.print();

    // Vérifier si on retrouve A
    a.print();

    let mut anew = Dense::zeros(S,S);

    product::lower_triangular_upper_triangular(&l, &u, &mut anew);

    anew.print();
}

fn test_lower_triangular_eye()
{
    const S: usize = 10;

    let a = LowerTriangular::eye(S);
}

fn test_par_jacobi()
{
    const S: usize = 10000;

    println!("1");
    let mut a = Dense::zeros(S,S);
    let mut x = Dense::zeros(S,1);

    let mut b = Dense::zeros(S,1);
    println!("2");

    for v in a.v.iter_mut()
    {
        *v = 0.5f64;
    }

    for i in 0..S
    {
        x.set(i,0,1f64);

        a.set(i,i,S as f64);
    } 

    println!("3");
    solve::dense::par_jacobi(&a, &b, &mut x, 0.01);

    x.print();
}

fn test_jacobi()
{
    const S: usize = 5;

    let mut a = Dense::zeros(S,S);
    let mut x = Dense::zeros(S,1);

    let mut b = Dense::zeros(S,1);


    for v in a.v.iter_mut()
    {
        *v = 0.5f64;
    }

    for i in 0..S
    {
        x.set(i,0,1f64);

        a.set(i,i,S as f64);
    } 
    
    solve::dense::jacobi(&a, &b, &mut x, 0.1);

    x.print();
}

fn test_dense()
{
    const S: usize = 5;

    let mut a = Dense::zeros(S,S);

    a.set(4,0,1f64);

    a.print();
}

fn test_diagonal()
{
    const S: usize = 5;

    let mut a = Diagonal::zeros(S);

    a.set(0,1f64);
    a.set(1,1f64);

    a.print();
}

fn test_symmetric()
{
    const S: usize = 5;

    let mut a = Symmetric::zeros(S);

    a.set(0,0,1f64);
    a.set(2,1,1f64);

    a.print();
}

fn test_tridiagonal()
{
    const S: usize = 5;

    let mut a = Tridiagonal::zeros(S);

    a.set(0,0,1f64);
    a.set(0,1,1f64);
    a.set(1,0,1f64);
    a.set(1,1,1f64);
    a.set(1,2,1f64);

    a.print();
}

fn test_upper_triangular()
{
    const S: usize = 5;

    let mut a = UpperTriangular::zeros(S);

    a.set(0,0,1f64);
    a.set(0,1,1f64);
    a.set(1,4,1f64);

    a.print();
}

fn test_lower_triangular()
{
    const S: usize = 5;

    let mut a = LowerTriangular::zeros(S);

    a.set(0,0,1f64);
    a.set(1,0,1f64);
    a.set(4,1,1f64);

    a.print();
} 

fn test_product_dense_dense()
{
    const S: usize = 1000;

    let mut a = Dense::zeros(S,S);
    let mut b = Dense::zeros(S,S);
    let mut p = Dense::zeros(S,S);

    a.set(0,0,1f64);
    a.set(0,1,2f64);
    a.set(0,2,3f64);
    a.set(1,1,4f64);
    a.set(2,0,2f64);
    a.set(2,1,1f64);
    a.set(2,2,2f64);

    b.set(0,2,1f64);
    b.set(1,0,2f64);
    b.set(1,1,3f64);
    b.set(1,2,4f64);
    b.set(2,1,3f64);
    b.set(2,2,2f64);

    product::dense_dense(&a, &b, &mut p);

    p.print();
}